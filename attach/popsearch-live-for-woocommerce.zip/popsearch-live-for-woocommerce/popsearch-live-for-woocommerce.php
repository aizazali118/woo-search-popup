<?php
/**
 * Plugin Name:       PopSearch Live for WooCommerce
 * Plugin URI:        https://smart-search-popup.vercel.app/
 * Description:       Fullscreen search popup with live product search, category slider and trending tags for your WooCommerce store.
 * Version:           1.2.0
 * Author:            Aizaz Ali Afridi
 * Author URI:        https://aizazaliafridi.com
 * Text Domain:       popsearch-live-for-woocommerce
 * Domain Path:       /languages
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 */

defined( 'ABSPATH' ) || exit;

/* ─── Constants ─────────────────────────────── */
define( 'PSLW_VERSION', '1.2.0' );
define( 'PSLW_FILE',    __FILE__ );
define( 'PSLW_DIR',     plugin_dir_path( __FILE__ ) );
define( 'PSLW_URL',     plugin_dir_url( __FILE__ ) );

/* ─── Declare HPOS compatibility ────────────── */
add_action( 'before_woocommerce_init', function () {
    if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
            'custom_order_tables', PSLW_FILE, true
        );
    }
} );

/* ─────────────────────────────────────────────
   1. ADMIN NOTICE — WooCommerce missing
───────────────────────────────────────────── */
add_action( 'admin_notices', function () {
    if ( ! class_exists( 'WooCommerce' ) ) {
        printf(
            '<div class="notice notice-error"><p><strong>PopSearch Live:</strong> %s</p></div>',
            esc_html__( 'WooCommerce must be installed and active to use this plugin.', 'popsearch-live-for-woocommerce' )
        );
    }
} );

/* ─────────────────────────────────────────────
   2. ENQUEUE FRONT-END ASSETS
───────────────────────────────────────────── */
add_action( 'wp_enqueue_scripts', function () {
    if ( ! class_exists( 'WooCommerce' ) ) return;

    wp_enqueue_style(
        'pslw-style',
        PSLW_URL . 'assets/style.css',
        [],
        PSLW_VERSION
    );

    $accent = get_option( 'pslw_accent_color', '#111111' );
    wp_add_inline_style( 'pslw-style', ':root{--ssp-accent:' . esc_attr( $accent ) . '}' );

    wp_enqueue_script(
        'pslw-script',
        PSLW_URL . 'assets/script.js',
        [ 'jquery' ],
        PSLW_VERSION,
        true
    );

    wp_localize_script( 'pslw-script', 'pslw_data', [
        'ajax_url'      => admin_url( 'admin-ajax.php' ),
        'nonce'         => wp_create_nonce( 'pslw_nonce' ),
        'shop_url'      => get_permalink( wc_get_page_id( 'shop' ) ) ?: home_url( '/shop/' ),
        'loading_text'  => __( 'Searching...', 'popsearch-live-for-woocommerce' ),
        'noresult_text' => __( 'No products found for', 'popsearch-live-for-woocommerce' ),
        'viewall_text'  => __( 'View all results', 'popsearch-live-for-woocommerce' ),
    ] );
} );

/* ─────────────────────────────────────────────
   3. ENQUEUE ADMIN ASSETS
───────────────────────────────────────────── */
add_action( 'admin_enqueue_scripts', function ( $hook ) {
    if ( $hook !== 'settings_page_pslw-settings' ) return;
    wp_enqueue_script(
        'pslw-admin',
        PSLW_URL . 'assets/admin.js',
        [],
        PSLW_VERSION,
        true
    );
} );

/* ─────────────────────────────────────────────
   4. TRENDING TAGS — auto-generated from store
───────────────────────────────────────────── */
function pslw_get_trending_tags( $limit = 8 ) {
    $manual = trim( (string) get_option( 'pslw_trending', '' ) );
    if ( $manual !== '' ) {
        $tags = array_filter( array_map( 'trim', explode( ',', $manual ) ) );
        if ( ! empty( $tags ) ) return array_values( $tags );
    }

    $tags = [];

    $cats = get_terms( [
        'taxonomy'   => 'product_cat',
        'hide_empty' => false,
        'orderby'    => 'count',
        'order'      => 'DESC',
        'number'     => 6,
        'exclude'    => get_option( 'default_product_cat' ),
    ] );
    if ( ! is_wp_error( $cats ) ) {
        foreach ( $cats as $c ) $tags[] = $c->name;
    }

    $ids = get_posts( [
        'post_type'      => 'product',
        'post_status'    => 'publish',
        'posts_per_page' => 14,
        'orderby'        => 'date',
        'order'          => 'DESC',
        'fields'         => 'ids',
    ] );
    foreach ( $ids as $pid ) {
        foreach ( explode( ' ', get_the_title( $pid ) ) as $w ) {
            $w = trim( $w, '.,;:!?"\'' );
            if ( strlen( $w ) > 3 ) { $tags[] = $w; break; }
        }
    }

    $seen = []; $result = [];
    foreach ( $tags as $t ) {
        $k = strtolower( trim( $t ) );
        if ( $k && ! isset( $seen[ $k ] ) ) {
            $seen[ $k ] = true;
            $result[]   = trim( $t );
        }
        if ( count( $result ) >= $limit ) break;
    }
    return $result;
}

/* ─────────────────────────────────────────────
   5. POPUP HTML — injected before </body>
───────────────────────────────────────────── */
add_action( 'wp_footer', 'pslw_render_popup', 5 );
function pslw_render_popup() {
    if ( ! class_exists( 'WooCommerce' ) ) return;

    $trending = pslw_get_trending_tags( 8 );

    $cats = get_terms( [
        'taxonomy'               => 'product_cat',
        'hide_empty'             => false,
        'number'                 => 0,
        'orderby'                => 'name',
        'order'                  => 'ASC',
        'exclude'                => get_option( 'default_product_cat' ),
        'update_term_meta_cache' => true,
    ] );
    if ( is_wp_error( $cats ) ) $cats = [];

    $cat_count  = count( $cats );
    $use_slider = $cat_count > 6;
    ?>
    <!-- PopSearch Live for WooCommerce v<?php echo esc_html( PSLW_VERSION ); ?> | By Aizaz Ali Afridi -->
    <div id="ssp-overlay" aria-hidden="true"></div>

    <div id="ssp-panel" role="dialog" aria-modal="true"
         aria-label="<?php esc_attr_e( 'Search Products', 'popsearch-live-for-woocommerce' ); ?>"
         aria-hidden="true">

        <button id="ssp-close" type="button"
                aria-label="<?php esc_attr_e( 'Close search', 'popsearch-live-for-woocommerce' ); ?>">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round">
                <line x1="18" y1="6" x2="6" y2="18"/>
                <line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
        </button>

        <h2 class="ssp-heading"><?php esc_html_e( 'What are you looking for?', 'popsearch-live-for-woocommerce' ); ?></h2>

        <!-- SEARCH BAR -->
        <div class="ssp-bar" role="search">
            <select id="ssp-cat-filter"
                    aria-label="<?php esc_attr_e( 'Filter by category', 'popsearch-live-for-woocommerce' ); ?>">
                <option value=""><?php esc_html_e( 'All categories', 'popsearch-live-for-woocommerce' ); ?></option>
                <?php foreach ( $cats as $cat ) : ?>
                    <option value="<?php echo esc_attr( $cat->slug ); ?>">
                        <?php echo esc_html( $cat->name ); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <input id="ssp-input" type="search"
                   placeholder="<?php esc_attr_e( 'Search for products...', 'popsearch-live-for-woocommerce' ); ?>"
                   autocomplete="off" autocorrect="off" spellcheck="false"
                   aria-label="<?php esc_attr_e( 'Search products', 'popsearch-live-for-woocommerce' ); ?>">
            <button id="ssp-search-btn" type="button"
                    aria-label="<?php esc_attr_e( 'Search', 'popsearch-live-for-woocommerce' ); ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                    <circle cx="11" cy="11" r="8"/>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"/>
                </svg>
            </button>
        </div>

        <!-- TRENDING TAGS -->
        <?php if ( ! empty( $trending ) ) : ?>
        <div class="ssp-trending" aria-label="<?php esc_attr_e( 'Trending searches', 'popsearch-live-for-woocommerce' ); ?>">
            <span class="ssp-trending-label"><?php esc_html_e( 'Trending:', 'popsearch-live-for-woocommerce' ); ?></span>
            <?php foreach ( $trending as $i => $tag ) : ?>
                <button class="ssp-tag<?php echo $i === 0 ? ' active' : ''; ?>"
                        data-term="<?php echo esc_attr( $tag ); ?>"
                        type="button">
                    <?php echo esc_html( $tag ); ?>
                </button>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- LIVE RESULTS -->
        <div id="ssp-live" role="listbox" aria-live="polite"
             aria-label="<?php esc_attr_e( 'Search results', 'popsearch-live-for-woocommerce' ); ?>"></div>

        <!-- POPULAR CATEGORIES -->
        <?php if ( ! empty( $cats ) ) : ?>
        <div id="ssp-categories">
            <div class="ssp-pop-title"><?php esc_html_e( 'Popular Categories', 'popsearch-live-for-woocommerce' ); ?></div>

            <?php if ( $use_slider ) : ?>
            <!-- SLIDER layout for 7+ categories -->
            <div class="ssp-slider-wrap">
                <button class="ssp-arrow ssp-arrow-prev" type="button"
                        aria-label="<?php esc_attr_e( 'Previous', 'popsearch-live-for-woocommerce' ); ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="#111" stroke-width="2.2"
                         stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="15 18 9 12 15 6"/>
                    </svg>
                </button>
                <div class="ssp-slider-viewport">
                    <div class="ssp-slider-track" id="ssp-slider-track">
                        <?php foreach ( $cats as $cat ) :
                            $tid = get_term_meta( $cat->term_id, 'thumbnail_id', true );
                            $img = $tid
                                ? wp_get_attachment_image_url( $tid, 'woocommerce_thumbnail' )
                                : wc_placeholder_img_src( 'woocommerce_thumbnail' );
                            $url = get_term_link( $cat );
                            if ( is_wp_error( $url ) ) continue;
                        ?>
                        <a href="<?php echo esc_url( $url ); ?>" class="ssp-cat-card">
                            <div class="ssp-cat-img">
                                <img src="<?php echo esc_url( $img ); ?>"
                                     alt="<?php echo esc_attr( $cat->name ); ?>"
                                     loading="lazy" width="148" height="148">
                            </div>
                            <div class="ssp-cat-name"><?php echo esc_html( $cat->name ); ?></div>
                            <div class="ssp-cat-count">
                                <?php echo absint( $cat->count ); ?>
                                <?php esc_html_e( 'products', 'popsearch-live-for-woocommerce' ); ?>
                            </div>
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <button class="ssp-arrow ssp-arrow-next" type="button"
                        aria-label="<?php esc_attr_e( 'Next', 'popsearch-live-for-woocommerce' ); ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="#111" stroke-width="2.2"
                         stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="9 18 15 12 9 6"/>
                    </svg>
                </button>
            </div>

            <?php else : ?>
            <!-- GRID layout for up to 6 categories -->
            <div class="ssp-cat-grid">
                <?php foreach ( $cats as $cat ) :
                    $tid = get_term_meta( $cat->term_id, 'thumbnail_id', true );
                    $img = $tid
                        ? wp_get_attachment_image_url( $tid, 'woocommerce_thumbnail' )
                        : wc_placeholder_img_src( 'woocommerce_thumbnail' );
                    $url = get_term_link( $cat );
                    if ( is_wp_error( $url ) ) continue;
                ?>
                <a href="<?php echo esc_url( $url ); ?>" class="ssp-cat-card">
                    <div class="ssp-cat-img">
                        <img src="<?php echo esc_url( $img ); ?>"
                             alt="<?php echo esc_attr( $cat->name ); ?>"
                             loading="lazy" width="148" height="148">
                    </div>
                    <div class="ssp-cat-name"><?php echo esc_html( $cat->name ); ?></div>
                    <div class="ssp-cat-count">
                        <?php echo absint( $cat->count ); ?>
                        <?php esc_html_e( 'products', 'popsearch-live-for-woocommerce' ); ?>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <a href="<?php echo esc_url( get_permalink( wc_get_page_id( 'shop' ) ) ?: home_url( '/shop/' ) ); ?>"
               class="ssp-view-all">
                <?php esc_html_e( 'View All Categories', 'popsearch-live-for-woocommerce' ); ?>
            </a>
        </div>
        <?php endif; ?>

    </div><!-- /ssp-panel -->
    <?php
}

/* ─────────────────────────────────────────────
   6. SHORTCODE  [pslw_search_button]
───────────────────────────────────────────── */
add_shortcode( 'pslw_search_button', function ( $atts ) {
    $atts = shortcode_atts( [ 'label' => '', 'class' => '' ], $atts );
    $extra = $atts['class'] ? ' ' . sanitize_html_class( $atts['class'] ) : '';
    ob_start(); ?>
    <button class="ssp-trigger<?php echo esc_attr( $extra ); ?>" type="button"
            aria-label="<?php esc_attr_e( 'Open search', 'popsearch-live-for-woocommerce' ); ?>">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
            <circle cx="11" cy="11" r="8"/>
            <line x1="21" y1="21" x2="16.65" y2="16.65"/>
        </svg>
        <?php if ( $atts['label'] ) echo esc_html( $atts['label'] ); ?>
    </button>
    <?php return ob_get_clean();
} );

/* ─────────────────────────────────────────────
   7. AJAX — LIVE PRODUCT SEARCH
───────────────────────────────────────────── */
add_action( 'wp_ajax_pslw_search',        'pslw_ajax_search' );
add_action( 'wp_ajax_nopriv_pslw_search', 'pslw_ajax_search' );

function pslw_ajax_search() {
    check_ajax_referer( 'pslw_nonce', 'nonce' );

    $query    = sanitize_text_field( wp_unslash( $_POST['query']    ?? '' ) );
    $cat_slug = sanitize_title(      wp_unslash( $_POST['category'] ?? '' ) );
    $limit    = absint( get_option( 'pslw_results_limit', 8 ) );

    if ( mb_strlen( $query ) < 2 ) {
        wp_send_json_error( [ 'message' => 'Query too short' ] );
    }

    $args = [
        'post_type'      => 'product',
        'post_status'    => 'publish',
        'posts_per_page' => $limit,
        's'              => $query,
        'no_found_rows'  => false,
    ];
    if ( $cat_slug ) {
        $args['tax_query'] = [ [
            'taxonomy' => 'product_cat',
            'field'    => 'slug',
            'terms'    => $cat_slug,
        ] ];
    }

    add_filter( 'posts_search', function ( $search, $q ) use ( $query ) {
        global $wpdb;
        if ( $q->get( 's' ) && $search ) {
            $ids = $wpdb->get_col( $wpdb->prepare(
                "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_sku' AND meta_value LIKE %s",
                '%' . $wpdb->esc_like( $query ) . '%'
            ) );
            if ( $ids ) {
                /* Wrap existing search clause so the OR stays inside the AND */
                $search = ' AND (' . ltrim( $search, ' AND' ) . ' OR '
                    . $wpdb->posts . '.ID IN ('
                    . implode( ',', array_map( 'intval', $ids ) ) . '))';
            }
        }
        return $search;
    }, 10, 2 );

    $loop     = new WP_Query( $args );
    $products = [];
    while ( $loop->have_posts() ) {
        $loop->the_post();
        $product = wc_get_product( get_the_ID() );
        if ( ! $product ) continue;
        $terms     = get_the_terms( get_the_ID(), 'product_cat' );
        $cat_names = ( $terms && ! is_wp_error( $terms ) )
            ? implode( ', ', wp_list_pluck( $terms, 'name' ) ) : '';
        $products[] = [
            'id'    => $product->get_id(),
            'name'  => $product->get_name(),
            'url'   => get_permalink(),
            'price' => $product->get_price_html(),
            'image' => get_the_post_thumbnail_url( null, 'woocommerce_thumbnail' )
                       ?: wc_placeholder_img_src(),
            'cat'   => $cat_names,
            'stock' => $product->is_in_stock(),
        ];
    }
    wp_reset_postdata();
    wp_send_json_success( [ 'products' => $products, 'total' => $loop->found_posts ] );
}

/* ─────────────────────────────────────────────
   8. SETTINGS PAGE
───────────────────────────────────────────── */
add_action( 'admin_menu', function () {
    add_options_page(
        __( 'PopSearch Live for WooCommerce', 'popsearch-live-for-woocommerce' ),
        __( 'PopSearch Live', 'popsearch-live-for-woocommerce' ),
        'manage_options', 'pslw-settings', 'pslw_settings_page'
    );
} );

function pslw_settings_page() {
    if ( isset( $_POST['pslw_save'] ) && check_admin_referer( 'pslw_settings' ) ) {
        update_option( 'pslw_trending',      sanitize_text_field( $_POST['pslw_trending'] ?? '' ) );
        update_option( 'pslw_results_limit', absint( $_POST['pslw_results_limit'] ?? 8 ) );
        update_option( 'pslw_accent_color',  sanitize_hex_color( $_POST['pslw_accent_color'] ?? '#111111' ) );
        echo '<div class="notice notice-success is-dismissible"><p>&#9989; Settings saved!</p></div>';
    }

    $trending = get_option( 'pslw_trending', '' );
    $limit    = get_option( 'pslw_results_limit', 8 );
    $accent   = get_option( 'pslw_accent_color', '#111111' );

    $shortcodes = [
        '[pslw_search_button]'                       => 'Icon only — default, paste anywhere',
        '[pslw_search_button label="Search"]'        => 'Icon + label text',
        '[pslw_search_button label="Find Products"]' => 'Icon + custom label',
    ];
    ?>
    <div class="wrap" style="max-width:820px">
        <h1 style="display:flex;align-items:center;gap:10px">
            <span style="font-size:26px">&#128269;</span>
            PopSearch Live for WooCommerce
        </h1>
        <p style="color:#666;margin-top:-6px">
            Version <?php echo esc_html( PSLW_VERSION ); ?> &nbsp;&bull;&nbsp;
            Developed by <strong>Aizaz Ali Afridi</strong>
        </p>

        <!-- SHORTCODE PANEL -->
        <div style="background:#fff;border:1px solid #ddd;border-radius:8px;padding:24px;margin:20px 0">
            <h2 style="margin-top:0">&#128203; Shortcodes — Click to Copy</h2>
            <p style="color:#666;margin-top:0">Use these in any page, widget, or Elementor HTML block.</p>
            <table style="width:100%;border-collapse:collapse">
                <?php foreach ( $shortcodes as $code => $desc ) : ?>
                <tr style="border-bottom:1px solid #f0f0f0">
                    <td style="padding:10px 8px;width:50%">
                        <code id="sc-<?php echo md5( $code ); ?>"
                              style="background:#f5f5f5;padding:7px 12px;border-radius:4px;font-size:13px;display:block;cursor:pointer;user-select:all"
                              title="Click to copy"
                              onclick="pslwCopyEl(this)">
                            <?php echo esc_html( $code ); ?>
                        </code>
                    </td>
                    <td style="padding:10px 8px;color:#555;font-size:13px">
                        <?php echo esc_html( $desc ); ?>
                    </td>
                    <td style="padding:10px 8px">
                        <button type="button"
                                onclick="pslwCopyEl(document.getElementById('sc-<?php echo md5( $code ); ?>'))"
                                style="background:#111;color:#fff;border:none;padding:6px 14px;border-radius:4px;cursor:pointer;font-size:12px;font-family:inherit">
                            Copy
                        </button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
            <p style="font-size:12px;color:#999;margin:12px 0 0">
                &#128161; <strong>Elementor:</strong> Add an HTML widget in your header &rarr; paste shortcode &rarr; done.
            </p>
        </div>

        <!-- SETTINGS FORM -->
        <form method="post">
            <?php wp_nonce_field( 'pslw_settings' ); ?>
            <div style="background:#fff;border:1px solid #ddd;border-radius:8px;padding:24px;margin-bottom:20px">
                <h2 style="margin-top:0">&#9881;&#65039; Settings</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="pslw_trending">Trending Tags</label></th>
                        <td>
                            <input type="text" id="pslw_trending" name="pslw_trending"
                                   value="<?php echo esc_attr( $trending ); ?>"
                                   class="regular-text"
                                   placeholder="Leave empty to auto-generate from your store">
                            <p class="description">
                                Comma separated: <code>Shirt,Shoes,Cap</code><br>
                                <strong>Leave empty</strong> = auto-pulled from your store's categories &amp; product names.
                                Hidden if the store has no products yet.
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="pslw_results_limit">Max Live Results</label></th>
                        <td>
                            <input type="number" id="pslw_results_limit" name="pslw_results_limit"
                                   value="<?php echo esc_attr( $limit ); ?>"
                                   min="3" max="20" class="small-text">
                            <p class="description">Number of products shown in live search (3–20)</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="pslw_accent_color">Accent Color</label></th>
                        <td>
                            <input type="color" id="pslw_accent_color" name="pslw_accent_color"
                                   value="<?php echo esc_attr( $accent ); ?>">
                            <p class="description">Search button, active tag &amp; View All button color</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button( 'Save Settings', 'primary', 'pslw_save' ); ?>
            </div>
        </form>

        <div style="background:#fff;border:1px solid #ddd;border-radius:8px;padding:24px">
            <h2 style="margin-top:0">&#8505;&#65039; Quick Notes</h2>
            <ul style="margin:0;padding-left:20px;color:#555;line-height:2.2">
                <li><strong>Category images:</strong> WooCommerce &rarr; Product Categories &rarr; Edit &rarr; upload Thumbnail</li>
                <li><strong>Slider</strong> activates automatically when you have more than 6 categories</li>
                <li><strong>Trending tags</strong> only appear when your store has products or categories</li>
                <li><strong>Live search</strong> matches product name, description &amp; SKU</li>
                <li>Compatible with Elementor, Divi, Astra, OceanWP, GeneratePress &amp; all major themes</li>
            </ul>
        </div>
    </div>
    <?php
}

/* ─────────────────────────────────────────────
   9. PLUGIN ACTION LINKS
───────────────────────────────────────────── */
add_filter( 'plugin_action_links_' . plugin_basename( PSLW_FILE ), function ( $links ) {
    array_unshift(
        $links,
        '<a href="' . admin_url( 'options-general.php?page=pslw-settings' ) . '">Settings</a>'
    );
    return $links;
} );
