/* PopSearch Live for WooCommerce — admin.js | By Aizaz Ali Afridi */
function pslwCopyEl( el ) {
    var text = el.textContent.trim();
    if ( navigator.clipboard ) {
        navigator.clipboard.writeText( text );
    } else {
        var t = document.createElement( 'textarea' );
        t.value = text;
        document.body.appendChild( t );
        t.select();
        document.execCommand( 'copy' );
        document.body.removeChild( t );
    }
    var orig     = el.style.background;
    var origText = el.textContent;
    el.style.background = '#d4edda';
    el.textContent      = 'Copied!';
    setTimeout( function () {
        el.style.background = orig;
        el.textContent      = origText;
    }, 1400 );
}
