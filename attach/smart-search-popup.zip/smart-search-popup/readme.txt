=== Smart Search Popup ===
Contributors:      aizazaliafridi
Tags:              search, ajax search, live search, product search, popup
Requires at least: 5.8
Tested up to:      6.9
Stable tag:        1.1.0
Requires PHP:      7.4
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

Fullscreen search popup with live product search, category slider and trending tags for WooCommerce stores.

== Description ==

Smart Search Popup gives your WooCommerce store a beautiful fullscreen search experience. When a visitor clicks the search icon, a smooth overlay opens showing:

* **Live product search** — results appear as they type (searches name, description and SKU)
* **Category filter** — dropdown to narrow results to one category before searching
* **Trending tags** — auto-generated from your real product categories and names; hidden if the store is empty
* **Popular Categories** — displayed as a grid (≤6) or a slider with black arrow buttons (7+)
* **One-click shortcodes** — copy any shortcode directly from the Settings page

= Key Features =

* Zero configuration required — works out of the box
* Inherits your theme's global font family — no visual conflicts
* Accent color picker in Settings — match your brand in seconds
* Category images pulled from WooCommerce Product Categories thumbnails
* Slider activates automatically when you have more than 6 categories
* Mobile responsive — stacks cleanly on small screens
* Fully accessible — ARIA roles, keyboard navigation, ESC to close
* Compatible with Elementor, Divi, Astra, OceanWP, GeneratePress, Flatsome, Storefront, Avada, Kadence, Blocksy, Hello Theme and more
* HPOS (High-Performance Order Storage) compatible
* GPL-2.0 licensed

= How to Add the Search Button =

After activation go to **Settings → Smart Search Popup** and copy any shortcode.

`[ssp_search_button]` — icon only (recommended for headers)
`[ssp_search_button label="Search"]` — icon with label
`[ssp_search_button label="Find Products"]` — icon with custom label

Paste the shortcode into an Elementor HTML widget, a Classic widget, or any PHP template:

`<?php echo do_shortcode('[ssp_search_button]'); ?>`

= Requirements =

* WordPress 5.8+
* WooCommerce 5.0+
* PHP 7.4+

== Installation ==

1. Upload the `smart-search-popup` folder to `/wp-content/plugins/`
   OR install via **Plugins → Add New → Upload Plugin** and upload the ZIP.
2. Activate the plugin through the **Plugins** menu in WordPress.
3. Make sure WooCommerce is installed and active.
4. Go to **Settings → Smart Search Popup**.
5. Copy a shortcode and paste it in your header (Elementor HTML widget or any widget area).

== Frequently Asked Questions ==

= Does this work without WooCommerce? =
No. The plugin requires WooCommerce to fetch products and categories.

= Why are my categories not showing? =
Categories are pulled from WooCommerce Product Categories. Make sure you have created categories under **WooCommerce → Product Categories**. All categories are shown regardless of product count.

= How do I add category images? =
Go to **WooCommerce → Product Categories → Edit** each category and upload a Thumbnail image.

= When does the slider appear? =
The category grid switches to a slider automatically when you have more than 6 categories.

= Why are trending tags not showing? =
Trending tags are hidden when the store has no products. Once you add products and/or categories they will appear automatically. You can also set manual tags in **Settings → Smart Search Popup**.

= How do I change the button color? =
Go to **Settings → Smart Search Popup** and use the Accent Color picker.

= Is it compatible with Elementor? =
Yes. Add an HTML widget in your Elementor header template and paste `[ssp_search_button]`.

= How do I copy the shortcode? =
Go to **Settings → Smart Search Popup** — each shortcode has a **Copy** button next to it.

== Screenshots ==

1. Search popup open — search bar, trending tags and category grid
2. Live search results appearing as the user types
3. Category slider with black arrow buttons (7+ categories)
4. Settings page with one-click shortcode copy buttons

== Changelog ==

= 1.1.0 =
* Renamed plugin to comply with WordPress.org guidelines
* Added readme.txt for WordPress.org submission
* Added one-click shortcode copy buttons on Settings page
* Added plugin action link to Settings from Plugins list
* Declared HPOS compatibility
* Improved accessibility — ARIA roles and labels
* Improved category fetch — hide_empty: false ensures all categories show

= 1.0.3 =
* All categories shown including 0-product ones
* Auto-generated trending tags from store products/categories
* Search button is icon-only by default
* Developer credit: Aizaz Ali Afridi

= 1.0.2 =
* Category slider with black arrow buttons for 7+ categories
* Search bar proportions fixed

= 1.0.1 =
* Search bar proportions fixed
* No bold fonts — inherits theme font family
* All text in English

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.1.0 =
Plugin renamed to comply with WordPress.org guidelines. Please deactivate the old version before activating this one.
