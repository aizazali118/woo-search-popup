/* Smart Search Popup — script.js v1.1.0 | By Aizaz Ali Afridi */
(function ($) {
  'use strict';

  var panel     = document.getElementById('ssp-panel');
  var overlay   = document.getElementById('ssp-overlay');
  var input     = document.getElementById('ssp-input');
  var live      = document.getElementById('ssp-live');
  var catSec    = document.getElementById('ssp-categories');
  var catSel    = document.getElementById('ssp-cat-filter');
  var searchBtn = document.getElementById('ssp-search-btn');
  var timer     = null;

  if ( ! panel ) return;

  /* ── OPEN / CLOSE ── */
  function openPopup() {
    panel.classList.add('ssp-open');
    overlay.classList.add('ssp-open');
    panel.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    setTimeout(function () { if (input) input.focus(); }, 360);
  }
  function closePopup() {
    panel.classList.remove('ssp-open');
    overlay.classList.remove('ssp-open');
    panel.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    if (input) input.value = '';
    hideLive();
  }

  /* Open triggers: shortcode button, any [data-ssp-open] element */
  document.addEventListener('click', function (e) {
    if (e.target.closest('.ssp-trigger, [data-ssp-open]')) {
      e.preventDefault(); openPopup();
    }
  });

  var closeEl = document.getElementById('ssp-close');
  if (closeEl)  closeEl.addEventListener('click', closePopup);
  if (overlay)  overlay.addEventListener('click', closePopup);
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && panel.classList.contains('ssp-open')) closePopup();
  });

  /* ── TRENDING TAGS ── */
  document.querySelectorAll('.ssp-tag').forEach(function (tag) {
    tag.addEventListener('click', function () {
      document.querySelectorAll('.ssp-tag').forEach(function (t) { t.classList.remove('active'); });
      this.classList.add('active');
      if (input) {
        input.value = this.dataset.term || '';
        input.dispatchEvent(new Event('input'));
        input.focus();
      }
    });
  });

  /* ── SEARCH BUTTON & ENTER ── */
  if (searchBtn) {
    searchBtn.addEventListener('click', function () {
      var q = input ? input.value.trim() : '';
      if (q) window.location.href = ssp_data.shop_url + '?s=' + encodeURIComponent(q) + '&post_type=product';
    });
  }
  if (input) {
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        var q = this.value.trim();
        if (q) window.location.href = ssp_data.shop_url + '?s=' + encodeURIComponent(q) + '&post_type=product';
      }
    });
    input.addEventListener('input', function () {
      clearTimeout(timer);
      var q = this.value.trim();
      if (q.length < 2) { hideLive(); return; }
      timer = setTimeout(function () { doSearch(q, catSel ? catSel.value : ''); }, 300);
    });
  }
  if (catSel) {
    catSel.addEventListener('change', function () {
      var q = input ? input.value.trim() : '';
      if (q.length >= 2) doSearch(q, this.value);
    });
  }

  /* ── AJAX LIVE SEARCH ── */
  function doSearch(query, category) {
    showLoading();
    $.ajax({
      url:  ssp_data.ajax_url,
      type: 'POST',
      data: { action: 'ssp_search', nonce: ssp_data.nonce, query: query, category: category || '' },
      success: function (res) {
        res.success ? renderResults(res.data.products, query, res.data.total) : showNoResults(query);
      },
      error: function () { showNoResults(query); }
    });
  }

  function renderResults(products, query, total) {
    if (!products || !products.length) { showNoResults(query); return; }
    var html = products.map(function (p) {
      return '<a class="ssp-result-item" href="' + esc(p.url) + '">' +
        '<img class="ssp-result-img" src="' + esc(p.image) + '" alt="' + esc(p.name) + '" loading="lazy">' +
        '<div class="ssp-result-info">' +
          '<div class="ssp-result-name">' + highlight(esc(p.name), query) + '</div>' +
          '<div class="ssp-result-cat">' + esc(p.cat) + '</div>' +
        '</div>' +
        '<div class="ssp-result-price">' + p.price + '</div>' +
      '</a>';
    }).join('');
    if (total > products.length) {
      html += '<a class="ssp-view-results" href="' + ssp_data.shop_url + '?s=' + encodeURIComponent(query) + '&post_type=product">' +
        ssp_data.viewall_text + ' ' + total + ' &rarr;</a>';
    }
    live.innerHTML = html;
    showLive();
  }

  function showLoading()    { live.innerHTML = '<div class="ssp-loading"><div class="ssp-spinner"></div> ' + ssp_data.loading_text + '</div>'; showLive(); }
  function showNoResults(q) { live.innerHTML = '<div class="ssp-no-results">' + ssp_data.noresult_text + ' &ldquo;' + esc(q) + '&rdquo;</div>'; showLive(); }
  function showLive()       { live.classList.add('ssp-show'); if (catSec) catSec.style.display = 'none'; }
  function hideLive()       { live.classList.remove('ssp-show'); live.innerHTML = ''; if (catSec) catSec.style.display = ''; }
  function highlight(t, q)  { return t.replace(new RegExp('(' + q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')', 'gi'), '<mark class="ssp-hl">$1</mark>'); }
  function esc(s)            { return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

  /* ── CATEGORY SLIDER ── */
  var track   = document.getElementById('ssp-slider-track');
  var prevBtn = document.querySelector('.ssp-arrow-prev');
  var nextBtn = document.querySelector('.ssp-arrow-next');

  if (track && prevBtn && nextBtn) {
    var cards      = Array.prototype.slice.call(track.querySelectorAll('.ssp-cat-card'));
    var totalCards = cards.length;
    var curIdx     = 0;

    function cardW() {
      return cards[0] ? (cards[0].getBoundingClientRect().width + 16) : 164;
    }
    function visibleCount() {
      var vw = track.parentElement ? track.parentElement.offsetWidth : window.innerWidth;
      return Math.max(1, Math.floor(vw / cardW()));
    }
    function maxIndex() {
      return Math.max(0, totalCards - visibleCount());
    }
    function slideTo(idx) {
      curIdx = Math.min(Math.max(idx, 0), maxIndex());
      track.style.transform = 'translateX(-' + (curIdx * cardW()) + 'px)';
      prevBtn.disabled = curIdx === 0;
      nextBtn.disabled = curIdx >= maxIndex();
    }

    prevBtn.addEventListener('click', function () { slideTo(curIdx - visibleCount()); });
    nextBtn.addEventListener('click', function () { slideTo(curIdx + visibleCount()); });

    setTimeout(function () { slideTo(0); }, 100);

    var resizeTimer;
    window.addEventListener('resize', function () {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(function () { slideTo(0); }, 150);
    });
  }

})(jQuery);
